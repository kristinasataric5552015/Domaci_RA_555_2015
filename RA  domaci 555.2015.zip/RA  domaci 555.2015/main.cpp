/*Srednja vrednost  n celih pozitivnih brojeva*/
#include <iostream>
#include<stdio.h>
using namespace std;
int main()
{
int n, brojac;
float suma, x;
suma = 0;
brojac = 0;
printf("Ukupno brojeva?\n");
scanf("%d",&n);
while(brojac<n) {
printf("Ukucajte %d. broj?", brojac+1);
scanf("%f",&x);
suma+=x;
brojac+=1;
	            }
printf("Srednja vrednost  unetih brojeva je %f\n",suma/n);
return 0;
}
